package com.ecoassets.model;

public enum EstadoDispositivo {
    NUEVO,
    USADO_COMO_NUEVO,
    USADO_BUEN_ESTADO,
    USADO_ESTADO_ACEPTABLE,
    PARA_REPUESTOS
}