package com.ecoassets.model;

public enum EstadoPuja {
    PENDIENTE,
    ACEPTADA,
    RECHAZADA
}